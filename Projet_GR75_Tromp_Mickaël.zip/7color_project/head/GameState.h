#ifndef GAME_STATE_H
#define GAME_STATE_H

typedef enum GR75_Color{		//Définit la couleur utilisée...
	ERROR = -1,
	EMPTY,
	PLAYER_1,
	PLAYER_2,
	RED,
	GREEN,
	BLUE,
	YELLOW,
	MAGENTA,
	CYAN,
	WHITE,
}GR75_Color; 		//...sous le nom Color

typedef struct GR75_GameState{	//Deux cases de la structure GameState
	GR75_Color* map;			//Un pointeur vers la couleur utilisée
	int size;					//La valeur de sa taille
} GR75_GameState;

int main(void);
void GR75_create_empty_game_state (GR75_GameState*, int);
void GR75_set_map_value (GR75_GameState*, int, int, int);
GR75_Color GR75_get_map_value (GR75_GameState*, int, int);
void GR75_fill_map(GR75_GameState*);
void GR75_Affichage(GR75_GameState*);
void GR75_Manuel(GR75_GameState*, int);
int GR75_Individuel(GR75_GameState*, int);

void GR75_MAJ(GR75_GameState*, int, int, int);
int GR75_NPTQ(GR75_GameState*, int);
int GR75_NPTQMPT(GR75_GameState*, int);
int GR75_Glouton(GR75_GameState*, int );
int GR75_Gagnant(GR75_GameState*);
int GR75_NbFrontieres(GR75_GameState*, int);
int GR75_NbCases(GR75_GameState*, int);
int GR75_Hegemonique(GR75_GameState*, int);
int GR75_Mixte(GR75_GameState*, int);

#endif