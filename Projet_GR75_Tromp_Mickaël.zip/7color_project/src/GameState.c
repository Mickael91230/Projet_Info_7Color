#include "../head/GameState.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

///////////////////////////////////////
//Fonctions de mise en place

const char* GR75_Couleur[9] = {"1","2","RED","GREEN","BLUE","YELLOW","MAGENTA","CYAN","WHITE"};

GR75_Color GR75_get_map_value(GR75_GameState* state, int x, int y){
	if ((state -> map == NULL) || (x > state -> size) || (y > state -> size)){
		printf("Y'a un pb dans get_map_value");
		return ERROR;
	}
	else if ((x==-1) || (x==state->size) || (y==-1) || (y==state->size)){		//Bordure du plateau
		return 0;
	}
	else{																		//Donner la couleur à la case renseignée
		return state -> map[y*state->size + x];
}	}

void GR75_create_empty_game_state(GR75_GameState* state, int size){
    state->size = size;
    state->map = malloc(sizeof(GR75_Color) * size * size);
    if (state->map == NULL) {
        printf("Il y a un problème d'allocation\n");
        exit(1);
}    }

void GR75_set_map_value(GR75_GameState* state, int x, int y, int value){
	state->map[y*state->size + x] = value;
}

void GR75_fill_map(GR75_GameState* state){
	for (int x = 0; x<state->size; x++){					//Parcourir toute la carte
		for (int y = 0; y<state->size; y++){
			int Place = 0;
			if ((x==state->size-1) && (y==0)){				//Placer les joueurs aux coins de la 2e diagonale
				Place = PLAYER_1;
			}
			else if ((x==0) && (y==state->size-1)){
				Place = PLAYER_2;
			}
			else{
				Place = rand()%MAGENTA+RED;					//Placer une couleur aléatoire parmi celles proposées
			}
			GR75_set_map_value(state,x,y,Place);
}   }	}	

void GR75_Affichage(GR75_GameState* state){
    for (int x = 0; x < state->size; x++){					//Parcourir toute la carte
		printf("\n");								//Afficher en sautant de ligne
        for (int y = 0; y < state->size; y++){
            int Valeur = GR75_get_map_value(state, x, y);	//Aller chercher la couleur dans la case
            if ((Valeur >= 1) && (Valeur <= 9)){
                printf("%s\t", GR75_Couleur[Valeur - 1]);	//Et l'afficher
            } else {
                printf("Invalid\t");
}	}	}printf("\n");
}

int GR75_Gagnant(GR75_GameState* state){
	int Taille = state->size;
	int Case1=0;
	int Case2=0;
	for (int x = 0; x < state->size ; x++){					//On parcourt la carte et on compte les cases de chaque joueur
		for (int y = 0 ; y < state->size ; y++){
			int Coul = GR75_get_map_value(state,x,y);
			if (Coul == PLAYER_1){
				Case1+=1;
			}
			else if (Coul == PLAYER_2){
				Case2+=1;
			}	}	}
	if (Case1 < Taille*Taille/2 && Case2 < Taille*Taille/2){		//Si le joueur n'a pas gagné
		printf("\n");
		return 0;
	}
	else if (Case1 == Case2 && Case1 == Taille*Taille/2){			//Si il a égalité
		return 3;
	}
	else{
		if (Case1 >= Taille*Taille/2){			//Si un joueur a gagné
			return PLAYER_1;
		}
		else{
			return PLAYER_2;
}	}	}

void GR75_MAJ(GR75_GameState* state, int size, int Joueur, int Couleur_jouee){
	int K=0;
	while (K!=1){
		for (int x=0; x < state->size; x++){
			if (K==1){
				break;
			}
			else{
				for (int y=0; y < state->size; y++){
			    	if (K==1){
				    	break;
			   		}
					int Couleur_locale = GR75_get_map_value(state, x, y);
					if (Couleur_locale == Couleur_jouee){
						int c[4]={0,0,0,0};
						c[0]=GR75_get_map_value(state, x, y+1);
						c[1]=GR75_get_map_value(state, x, y-1);
						c[2]=GR75_get_map_value(state, x+1, y);
						c[3]=GR75_get_map_value(state, x-1, y);
						for (int pos=0; pos<4; pos++){
							if (c[pos] == Joueur){
								GR75_set_map_value(state, x,y, Joueur);
								K=1;
								break;
		}	}	}	}	}	}
		if (K==1){
			K=0;
        }
		else{
			K=1;
}	}	}

///////////////////////////////////////
//Fonctions de jeu

/*int main(){
	srand(time(NULL));
	printf("Tout commence!\n");
	int Joueur = PLAYER_1;								//Joueur débutant la partie (arbitraire)
	int Joueur1 = 0;							//Compteur de victoires du joueur 1
	int Joueur2 = 0;							//Compteur de victoires du joueur 2
	int Egalites = 0;							//Compteur des égalités
	int size = 12;												//Taille de la carte
	int Gain = 0;
	int CouleurChoisie = 0;
	for (int partie = 0; partie < 500; partie++){
		GR75_GameState state;
		GR75_create_empty_game_state(&state,size);			//Création de la carte
		GR75_fill_map(&state);								//Remplissage de la carte
		GR75_Affichage(&state);
		while (Gain == 0){
			if (Joueur == PLAYER_2){					//Le joueur 1 joue
				Joueur = PLAYER_1;
	//			CouleurChoisie = GR75_Individuel(&state, Joueur)+1;
	//			CouleurChoisie = GR75_NPTQ(&state, Joueur);
	//			CouleurChoisie = GR75_NPTQMPT(&state, Joueur);
	//			CouleurChoisie = GR75_Glouton(&state, Joueur);
	//			CouleurChoisie = GR75_Hegemonique(&state, Joueur);
				CouleurChoisie = GR75_Mixte(&state, Joueur);
			}
			else if (Joueur == PLAYER_1){				//Le joueur 2 joue
				Joueur = PLAYER_2;
				CouleurChoisie = GR75_Individuel(&state, Joueur)+1;
	//			CouleurChoisie = GR75_NPTQ(&state, Joueur);
	//			CouleurChoisie = GR75_NPTQMPT(&state, Joueur);
	//			CouleurChoisie = GR75_Glouton(&state, Joueur);
	//			CouleurChoisie = GR75_Hegemonique(&state, Joueur);
	//			CouleurChoisie = GR75_Mixte(&state, Joueur);
			}
			if (CouleurChoisie != Joueur && CouleurChoisie != 15){
				GR75_MAJ(&state, size, Joueur, CouleurChoisie);
				printf("Joueur %i joue %i\n", Joueur, CouleurChoisie);	//Visualiser la carte à chaque coup
				GR75_Affichage(&state);
			}
			else if (CouleurChoisie == 15){				//Couleur aberrante: le joueur ne peut plus jouer
				if (Joueur == PLAYER_1){				//Alors son adversaire gagne
					Gain = 2;
					break;
				}
				else{
					Gain = 1;
					break;
			}	}
			Gain = GR75_Gagnant(&state);
		}
		if (Gain == PLAYER_1){							//Définition du gagnant total
			Joueur1 += 1;
		}
		else if (Gain == PLAYER_2){
			Joueur2 += 1;
		}
		else{
			Egalites += 1;
		}
		free(state.map);
	}
	if (Joueur1 > Joueur2){
		printf("Le joueur qui a le plus gagné est le joueur 1: %i parties remportées par %i contre %i par %i et %i égalités\n", Joueur1, PLAYER_1, Joueur2, PLAYER_2, Egalites);
	}
	else if (Joueur1 < Joueur2){
		printf("Le joueur qui a le plus gagné est le joueur 2: %i parties remportées par %i contre %i par %i et %i égalités\n", Joueur1, PLAYER_1, Joueur2, PLAYER_2, Egalites);
	}
	return 0;
}*/

int main(){
	srand(time(NULL));
	printf("Tout commence!\n");
	int Joueur = PLAYER_1;								//Joueur débutant la partie (arbitraire)
	int size = 12;
	GR75_GameState state;
	GR75_create_empty_game_state(&state,size);			//Création de la carte
	GR75_fill_map(&state);								//Remplissage de la carte
	GR75_Affichage(&state);								//Affichage de la carte initiale
	printf("\n");
	int Gain = 0;
	int CouleurChoisie = 0;
	while (Gain == 0){
		if (Joueur == PLAYER_2){					//Le joueur 1 joue en maximisant ses coups
			Joueur = PLAYER_1;
//			CouleurChoisie = GR75_Individuel(&state, Joueur)+1;
//			CouleurChoisie = GR75_NPTQ(&state, Joueur);
//			CouleurChoisie = GR75_NPTQMPT(&state, Joueur);
//			CouleurChoisie = GR75_Glouton(&state, Joueur);
//			CouleurChoisie = GR75_Hegemonique(&state, Joueur);
			CouleurChoisie = GR75_Mixte(&state, Joueur);	
		}
		else if (Joueur == PLAYER_1){				//Le joueur 2 joue aléatoirement
			Joueur = PLAYER_2;
			CouleurChoisie = GR75_Individuel(&state, Joueur)+1;
//			CouleurChoisie = GR75_NPTQ(&state, Joueur);
//			CouleurChoisie = GR75_NPTQMPT(&state, Joueur);
//			CouleurChoisie = GR75_Glouton(&state, Joueur);
//			CouleurChoisie = GR75_Hegemonique(&state, Joueur);
//			CouleurChoisie = GR75_Mixte(&state, Joueur);
		}
		if (CouleurChoisie != Joueur && CouleurChoisie != 15){
			GR75_MAJ(&state, size, Joueur, CouleurChoisie);
			printf("Joueur %i joue %i\n", Joueur, CouleurChoisie);	//Visualiser la carte à chaque coup
			GR75_Affichage(&state);
		}
		else if (CouleurChoisie == 15){				//Couleur aberrante: le joueur ne peut plus jouer
			if (Joueur == PLAYER_1){				//Alors son adversaire gagne
				Gain = 2;
				break;
			}
			else{
				Gain = 1;
				break;
		}	}
		Gain = GR75_Gagnant(&state);
	}
	printf("Le gagnant est le joueur %i. La carte finale est:\n",Gain);
	GR75_Affichage(&state);
	printf("\n");
	free(state.map);
	return 0;
}

//const char* GR75_Couleur[9] = {"1","2","RED","GREEN","BLUE","YELLOW","MAGENTA","CYAN","WHITE"};

int GR75_Individuel(GR75_GameState* state, int Joueur){
	int Couleur_jouee = 0;
	printf("Au joueur %i de jouer !\nVotre couleur:", Joueur);
	scanf("%i", &Couleur_jouee);
	return Couleur_jouee;
}

void GR75_Manuel(GR75_GameState* state, int size){
	int Joueur = PLAYER_1;
	int Couleur_jouee = 0;
	int Gain = 0;
	while(Gain != 1){					//Tant qu'il n'y a pas de gagnant
		if (Joueur == PLAYER_1){
			Joueur = PLAYER_2;
		}
		else{
		    Joueur = PLAYER_1;
		}
		printf("Au joueur %i de jouer!\n",Joueur);
		printf("Joueur: %i\n",Joueur);
		scanf("%i", &Couleur_jouee);
		Couleur_jouee += 1;
		printf("Joueur: %i\n",Joueur);
		printf("Couleur_A_jouer: %i\n", Couleur_jouee);
		GR75_MAJ(state, size, Joueur, Couleur_jouee);
		Gain = GR75_Gagnant(state);
		GR75_Affichage(state);
}	}

int GR75_NPTQ(GR75_GameState* state, int Joueur){
	int Couleur_Jouee = rand()%7 + 3;
	return Couleur_Jouee;
}

int GR75_NPTQMPT(GR75_GameState* state, int Joueur){
	int CouleurChoisie = 0;
	int Choix[7]={0,0,0,0,0,0,0};
	for (int x=0; x < state->size; x++){
		for (int y=0; y < state->size; y++){
			int Couleur_locale = GR75_get_map_value(state,x,y);
			if (Couleur_locale == Joueur){
				int C[4]={0,0,0,0};
				C[0] = GR75_get_map_value(state, x-1, y);
				C[1] = GR75_get_map_value(state, x+1, y);
				C[2] = GR75_get_map_value(state, x, y-1);
		        C[3] = GR75_get_map_value(state, x, y+1);
				for (int index=0; index<4; index++){
					if (C[index]!=0 && C[index]!=PLAYER_1 && C[index]!=PLAYER_2){	//Ne pas sélectionner l'extérieur ou un joueur
						int h = 0;
						for (int k=0; k<7; k++){
							if (C[index] != Choix[k]){
								if (Choix[k] == 0){
									Choix[k]=C[index];
									h = 1;
							}	}
							if (h == 1){
								break;
	}	}   }	}	}	}	}
	int k=0;
	while (Choix[k]!=0){
		k+=1;
	}
	if (k==0){
		printf("Le joueur ne peut plus jouer\n");
		return Joueur;
	}
	int Indice = rand()%k;								//La couleur est aléatoire parmi les choix de voisins
	CouleurChoisie = Choix[Indice];
	return CouleurChoisie;
}

int GR75_Glouton(GR75_GameState* state, int Joueur){
	GR75_GameState Copie[7];										//Création des cartes simulées
    for (int i = 0; i < 7; i++){
        GR75_create_empty_game_state(&Copie[i], state->size);
    }
    for (int x = 0; x < state->size; x++){					//Remplissage des cartes simulées
        for (int y = 0; y < state->size; y++){
            GR75_Color value = GR75_get_map_value(state, x, y);
            for (int i = 0; i < 7; i++){
                GR75_set_map_value(&Copie[i], x, y, value);
    }	}	}

    for (int i = 0; i < 7; i++){							//Simulation avec chaque couleur
        GR75_MAJ(&Copie[i], state->size, Joueur, i + 3);
    }
    int Nb0 = GR75_NbCases(state, Joueur);
    int Nb[7] = {0};
    for (int i = 0; i < 7; i++){				//Compter les cases pour chaque simulation
        Nb[i] = GR75_NbCases(&Copie[i], Joueur);
    }
	for (int i = 0; i < 7; i++){				//Ne pas oublier de libérer la mémoire
        free(Copie[i].map);
    }
	int DifferenceMax = -15;					//Initialisation du gain maximal en fonction de la couleur jouée
	int CouleurAPrendre = 0;					//Initialisation de la couleur à jouer dans la partie réelle
	int Compteur = 0;
	for (int i = 0; i < 7; i++){
		if (Nb[i] - Nb0 > DifferenceMax){		//Combien de cases ont été conquises lors de cette simulation
			DifferenceMax = Nb[i] - Nb0;
			CouleurAPrendre = i + 3;
			Compteur += 1;
	}	}
	if (Compteur <= 0){							//Si le joueur ne peut plus augmenter son territoire il ne joue plus
		CouleurAPrendre = 15;
	}
	return CouleurAPrendre;
}

int GR75_NbCases(GR75_GameState* state, int Joueur){
	int Compteur = 0;									//Compte le nombre de cases dont la valeur est celle du joueur
	for (int x = 0; x < state->size; x++){
		for (int y = 0; y < state->size; y++){
			if (GR75_get_map_value(state, x, y) == Joueur){
				Compteur += 1;
			}	}	}
	return Compteur;
}

int GR75_Hegemonique(GR75_GameState* state, int Joueur){
	GR75_GameState Copie[7];													//Création des cartes simulées
    for (int i = 0; i < 7; i++){
        GR75_create_empty_game_state(&Copie[i], state->size);
    }
    for (int x = 0; x < state->size; x++){
        for (int y = 0; y < state->size; y++){
            GR75_Color value = GR75_get_map_value(state, x, y);
            for (int i = 0; i < 7; i++) {
                GR75_set_map_value(&Copie[i], x, y, value);
            }	}	}

    for (int i = 0; i < 7; i++){												//Simulation de chaque coup
        GR75_MAJ(&Copie[i], state->size, Joueur, i + 3);
    }

    int Nb0 = GR75_NbFrontieres(state, Joueur);
    int Nb[7] = {0};
    for (int i = 0; i < 7; i++){
        Nb[i] = GR75_NbFrontieres(&Copie[i], Joueur);
    }

	for (int i = 0; i < 7; i++){				//Désallocation de la mémoire
        free(Copie[i].map);
    }

	int DifferenceMax = -15;					//Initialisation du gain maximal en fonction de la couleur jouée
	int CouleurAPrendre = 0;					//Initialisation de la couleur à jouer dans la partie réelle
	int Compteur = 0;
	for (int i = 0; i < 7; i++){
		if (Nb[i] - Nb0 >= DifferenceMax){		//Combien de frontières ont été gagnées lors de cette simulation
			DifferenceMax = Nb[i] - Nb0;
			CouleurAPrendre = i + 3;
			Compteur += 1;
	}	}
	if (DifferenceMax <= 0){					//Si le joueur ne peut plus augmenter ses frontières il ne joue plus
		CouleurAPrendre = 15;
	}
	return CouleurAPrendre;
}

int GR75_NbFrontieres(GR75_GameState* state, int Joueur){
	int Compteur = 0;
	for (int x = 0; x < state->size; x++){
		for (int y = 0; y < state->size; y++){
			if (GR75_get_map_value(state, x, y) == Joueur){
				int C[4]={0,0,0,0};
				C[0] = GR75_get_map_value(state, x-1, y);
				C[1] = GR75_get_map_value(state, x+1, y);
				C[2] = GR75_get_map_value(state, x, y-1);
		        C[3] = GR75_get_map_value(state, x, y+1);
				for (int index=0; index<4; index++){
					if ((C[index]!=0) && (C[index]!=Joueur)){
						Compteur+=1;
	}	}	}	}	}
	return Compteur;
}

int GR75_Mixte(GR75_GameState* state, int Joueur){
	GR75_GameState Copie[7];													//Création des cartes simulées
    for (int i = 0; i < 7; i++){
        GR75_create_empty_game_state(&Copie[i], state->size);
    }
    for (int x = 0; x < state->size; x++){
        for (int y = 0; y < state->size; y++){
            GR75_Color value = GR75_get_map_value(state, x, y);
            for (int i = 0; i < 7; i++) {
                GR75_set_map_value(&Copie[i], x, y, value);
    }	}	}

    for (int i = 0; i < 7; i++){												//Simulation de chaque coup
        GR75_MAJ(&Copie[i], state->size, Joueur, i + 3);
    }

    int Nb0 = GR75_NbFrontieres(state, Joueur);								//Compter le nombre de frontières
    int Nb[7] = {0};
    for (int i = 0; i < 7; i++){
        Nb[i] = GR75_NbFrontieres(&Copie[i], Joueur);
    }

	for (int i = 0; i < 7; i++){											//Tout désallouer
        free(Copie[i].map);
    }

	int DifferenceMax = 0;						//Initialisation du gain maximal en fonction de la couleur jouée
	int CouleurAPrendre = 0;					//Initialisation de la couleur à jouer dans la partie réelle
	int Compteur = 0;
	for (int i = 0; i < 7; i++){
		if (Nb[i] - Nb0 > DifferenceMax){		//Combien de cases ont été conquises lors de cette simulation
			DifferenceMax = Nb[i] - Nb0;
			CouleurAPrendre = i + 3;
			Compteur+=1;
	}	}
	if (Compteur == 0){							// Si il ne peut plus jouer, le joueur passe en mode Glouton
		CouleurAPrendre = GR75_Glouton(state, Joueur);
	}
	return CouleurAPrendre;
}